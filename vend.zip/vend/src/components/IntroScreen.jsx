import { useEffect, useRef, useState } from 'react'
import './IntroScreen.css'

function IntroScreen({
  videoSrc,
  isFirstVideo,
  isTransitioning,
  iconsVisible,
  iconsFading,
  onVideoEnded,
}) {
  const videoRef = useRef(null)
  const [isMuted, setIsMuted] = useState(!isFirstVideo)

  useEffect(() => {
    const video = videoRef.current
    if (!video) return

    let cancelled = false

    if (!isFirstVideo) {
      video.muted = true
      setIsMuted(true)
      video.play()?.catch(() => {})
      return () => { cancelled = true }
    }

    video.muted = false
    Promise.resolve(video.play()).then(() => {
      if (!cancelled) setIsMuted(video.muted)
    }).catch(() => {
      if (cancelled) return
      // Autoplay with sound may be blocked. Continue the video muted instead of stopping it.
      video.muted = true
      setIsMuted(true)
      video.play()?.catch(() => {})
    })

    return () => { cancelled = true }
  }, [videoSrc, isFirstVideo])

  const toggleVideoSound = () => {
    const video = videoRef.current
    if (!video) return
    const nextMuted = !video.muted
    video.muted = nextMuted
    setIsMuted(nextMuted)
    if (!nextMuted && video.paused) {
      video.play()?.catch(() => {
        video.muted = true
        setIsMuted(true)
      })
    }
  }

  return (
    <main className="video-screen">
      {/* Load the main-page logo while the intro videos are playing. */}
      <img className="logo-preload" src="/logo.webp" alt="" aria-hidden="true" fetchPriority="high" />
      <img className="background-preload" src="/background.webp" alt="" aria-hidden="true" fetchPriority="high" />
      <video
        className="mainpage-model-preload"
        src="/videos/video_2026-10-16_03-33-06_2x_upscaled-ezgif.com-video-to-webm-converter.webm"
        preload="auto"
        muted
        playsInline
        aria-hidden="true"
      />

      {iconsVisible && (
        <>
          <img
            className={`page-icon page-icon--top-left ${iconsFading ? 'page-icon--fade-out' : ''}`}
            src="/icons/icon-2.webp"
            alt=""
          />
          <img
            className={`page-icon page-icon--bottom-right ${iconsFading ? 'page-icon--fade-out' : ''}`}
            src="/icons/icon-1.webp"
            alt=""
          />
        </>
      )}

      <video
        ref={videoRef}
        className={`intro-video ${isFirstVideo ? 'intro-video--cover' : 'intro-video--fade-in'} ${isTransitioning ? 'intro-video--fade-out' : ''}`}
        src={videoSrc}
        autoPlay
        muted={!isFirstVideo}
        playsInline
        onEnded={onVideoEnded}
        aria-label="Intro video"
      />
      {isFirstVideo && (
        <button
          className="intro-sound-toggle"
          type="button"
          aria-label={isMuted ? 'Turn video sound on' : 'Mute video'}
          aria-pressed={!isMuted}
          title={isMuted ? 'Turn sound on' : 'Mute sound'}
          onClick={toggleVideoSound}
        >
          {isMuted ? (
            <svg viewBox="0 0 24 24" aria-hidden="true">
              <path d="M11 5 6 9H3v6h3l5 4V5Zm4 4 6 6m0-6-6 6" />
            </svg>
          ) : (
            <svg viewBox="0 0 24 24" aria-hidden="true">
              <path d="M11 5 6 9H3v6h3l5 4V5Zm4 4a5 5 0 0 1 0 6m3-9a9 9 0 0 1 0 12" />
            </svg>
          )}
        </button>
      )}
    </main>
  )
}

export default IntroScreen
