import { useEffect, useRef, useState } from 'react'
import './MusicPlayer.css'

const TRACKS = [
  {
    src: '/music/Hush.mp3',
    cover: '/music/covers/HUSH.webp',
    title: 'HUSH',
    artist: 'DJ DEADHORSES',
  },
  {
    src: '/music/AgonyOST.mp3',
    cover: '/music/covers/AgonyOST.webp',
    title: 'Light Stops Dripping Through The Stars (Sewerslvt Remix)',
    artist: 'AgonyOST & Sewerslvt',
  },
  { src: '/music/Alone.mp3', cover: '/music/covers/Alone.webp', title: 'Alone', artist: 'Sxnctuary' },
  { src: '/music/RoofJumping.mp3', cover: '/music/covers/Roof Jumping.webp', title: 'Roof Jumping', artist: 'RQ' },
  { src: '/music/Thunderbolt.mp3', cover: '/music/covers/Thunderbolt.webp', title: 'Thunderbolt', artist: 'SPXRXT' },
]

function formatTime(value) {
  if (!Number.isFinite(value) || value < 0) return '0:00'
  const seconds = Math.floor(value)
  return `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, '0')}`
}

function MusicPlayer({ startWhenReady = false }) {
  const [isOpen, setIsOpen] = useState(false)
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const [trackIndex, setTrackIndex] = useState(0)
  const [radarActive, setRadarActive] = useState(false)
  const [autoplayBlocked, setAutoplayBlocked] = useState(false)
  const playerRef = useRef(null)
  const audioRef = useRef(null)
  const startAttemptedRef = useRef(false)
  const playAfterTrackChangeRef = useRef(false)

  const track = TRACKS[trackIndex]
  const progress = duration > 0 ? (currentTime / duration) * 100 : 0

  const playAudio = () => {
    const audio = audioRef.current
    if (!audio) return
    audio.play().then(() => setAutoplayBlocked(false)).catch(() => setAutoplayBlocked(true))
  }

  useEffect(() => {
    if (!isOpen) return undefined
    const closeOnOutsideClick = (event) => {
      if (!playerRef.current?.contains(event.target)) setIsOpen(false)
    }
    const closeOnEscape = (event) => {
      if (event.key === 'Escape') setIsOpen(false)
    }
    document.addEventListener('pointerdown', closeOnOutsideClick)
    document.addEventListener('keydown', closeOnEscape)
    return () => {
      document.removeEventListener('pointerdown', closeOnOutsideClick)
      document.removeEventListener('keydown', closeOnEscape)
    }
  }, [isOpen])

  useEffect(() => {
    const audio = audioRef.current
    if (!audio) return
    audio.load()
    if (playAfterTrackChangeRef.current) {
      playAfterTrackChangeRef.current = false
      playAudio()
    }
  }, [trackIndex])

  useEffect(() => {
    if (!startWhenReady || startAttemptedRef.current) return
    startAttemptedRef.current = true
    playAudio()
  }, [startWhenReady])

  useEffect(() => {
    if (!isPlaying) return undefined
    let frameId
    const updateProgress = () => {
      const audio = audioRef.current
      if (!audio) return
      setCurrentTime(audio.currentTime || 0)
      frameId = window.requestAnimationFrame(updateProgress)
    }
    frameId = window.requestAnimationFrame(updateProgress)
    return () => window.cancelAnimationFrame(frameId)
  }, [isPlaying, trackIndex])

  const changeTrack = (nextIndex, shouldPlay) => {
    const audio = audioRef.current
    playAfterTrackChangeRef.current = shouldPlay
    if (audio) audio.pause()
    setCurrentTime(0)
    setDuration(0)
    setTrackIndex((nextIndex + TRACKS.length) % TRACKS.length)
  }

  const togglePlayback = () => {
    const audio = audioRef.current
    if (!audio) return
    if (audio.paused) {
      if (duration > 0 && currentTime >= duration) audio.currentTime = 0
      playAudio()
    } else {
      audio.pause()
    }
  }

  const restartTrack = () => {
    const audio = audioRef.current
    if (!audio) return
    audio.currentTime = 0
    setCurrentTime(0)
  }

  const seekTo = (event) => {
    const time = Number(event.target.value)
    const audio = audioRef.current
    if (audio && Number.isFinite(time)) {
      audio.currentTime = time
      setCurrentTime(time)
    }
  }

  const handlePrevious = () => {
    if (currentTime > 3) {
      restartTrack()
      return
    }
    changeTrack(trackIndex - 1, isPlaying)
  }

  const handleNext = () => changeTrack(trackIndex + 1, isPlaying)

  const handleEnded = () => changeTrack(trackIndex + 1, true)

  return (
    <div className={`music-player ${isOpen ? 'music-player--open' : ''}`} ref={playerRef}>
      <audio
        ref={audioRef}
        src={track.src}
        preload="auto"
        onPlay={() => { setIsPlaying(true); setAutoplayBlocked(false) }}
        onPause={(event) => {
          setIsPlaying(false)
          if (!playAfterTrackChangeRef.current) {
            setCurrentTime(event.currentTarget.currentTime || 0)
          }
        }}
        onLoadedMetadata={(event) => setDuration(Number.isFinite(event.currentTarget.duration) ? event.currentTarget.duration : 0)}
        onDurationChange={(event) => setDuration(Number.isFinite(event.currentTarget.duration) ? event.currentTarget.duration : 0)}
        onTimeUpdate={(event) => setCurrentTime(event.currentTarget.currentTime || 0)}
        onEnded={handleEnded}
        onError={() => setAutoplayBlocked(true)}
      />

      <div className={`music-player__island ${isOpen ? 'music-player__island--open' : ''} ${isPlaying ? 'music-player__island--playing' : ''}`}>
        <button className="music-player__face" type="button" aria-label="Open music player" aria-expanded={isOpen} onClick={() => setIsOpen((open) => !open)}>
          <img src={track.cover} alt={`${track.title} cover`} />
          <span className="music-player__ring" style={{ '--progress': `${progress}%` }} />
        </button>

        <div className="music-player__content" aria-hidden={!isOpen}>
          <div className="music-player__track">
            <img className="music-player__art" src={track.cover} alt={`${track.title} cover`} />
            <div className="music-player__details">
              <span className="music-player__title" title={track.title}>{track.title}</span>
              <span className="music-player__artist">{track.artist}</span>
            </div>
          </div>

          <div className="music-player__controls">
            <div className="music-player__times">
              <span>{formatTime(currentTime)}</span>
              <span>{formatTime(Math.max(0, duration - currentTime))}</span>
            </div>
            <input
              className="music-player__seek"
              type="range"
              min="0"
              max={duration || 1}
              step="any"
              value={Math.min(currentTime, duration || 1)}
              aria-label="Seek through track"
              aria-valuetext={`${formatTime(currentTime)} of ${formatTime(duration)}`}
              style={{ '--progress': `${progress}%` }}
              onChange={seekTo}
            />
            <div className="music-player__buttons">
              <button type="button" aria-label="Previous track" onClick={handlePrevious}>
                <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M.5 3.5A.5.5 0 0 0 0 4v8a.5.5 0 0 0 1 0V8.753l6.267 3.636c.54.313 1.233-.066 1.233-.697v-2.94l6.267 3.636c.54.314 1.233-.065 1.233-.696V4.308c0-.63-.693-1.01-1.233-.696L8.5 7.248v-2.94c0-.63-.692-1.01-1.233-.696L1 7.248V4a.5.5 0 0 0-.5-.5" /></svg>
              </button>
              <button className="music-player__play" type="button" aria-label={isPlaying ? 'Pause' : 'Play'} onClick={togglePlayback}>
                {isPlaying ? <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4 3h3v10H4zm5 0h3v10H9z" /></svg> : <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4 2.7c0-.6.65-.96 1.16-.65l7.4 4.45a1.75 1.75 0 0 1 0 3L5.16 13.95A.75.75 0 0 1 4 13.3z" /></svg>}
              </button>
              <button type="button" aria-label="Next track" onClick={handleNext}>
                <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M15.5 3.5a.5.5 0 0 1 .5.5v8a.5.5 0 0 1-1 0V8.753l-6.267 3.636c-.54.313-1.233-.066-1.233-.697v-2.94l-6.267 3.636C.693 12.703 0 12.324 0 11.693V4.308c0-.63.693-1.01 1.233-.696L7.5 7.248v-2.94c0-.63.692-1.01 1.233-.696L15 7.248V4a.5.5 0 0 1 .5-.5" /></svg>
              </button>
              <button className={`music-player__radar ${radarActive ? 'is-active' : ''}`} type="button" aria-label="Toggle radar effect" aria-pressed={radarActive} onClick={() => setRadarActive((active) => !active)}>
                <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M6.634 1.135A7 7 0 0 1 15 8a.5.5 0 0 1-1 0 6 6 0 1 0-6.5 5.98v-1.005A5 5 0 1 1 13 8a.5.5 0 0 1-1 0 4 4 0 1 0-4.5 3.969v-1.011A2.999 2.999 0 1 1 11 8a.5.5 0 0 1-1 0 2 2 0 1 0-2.5 1.936v-1.07a1 1 0 1 1 1 0V15.5a.5.5 0 0 1-1 0v-.518a7 7 0 0 1-.866-13.847" /></svg>
              </button>
            </div>
            <span className="music-player__sr-status" role="status" aria-live="polite">
              {autoplayBlocked ? 'Automatic playback was blocked. Press Play to start music.' : ''}
            </span>
          </div>
        </div>
      </div>
    </div>
  )
}

export default MusicPlayer
