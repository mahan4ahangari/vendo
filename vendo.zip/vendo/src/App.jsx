import { useState } from 'react'
import IntroScreen from './components/IntroScreen.jsx'
import MainPage from './pages/MainPage.jsx'

const FIRST_VIDEO = '/videos/video_2026-10-16_03-22-27_upscaled-ezgif.com-mp4-to-webm-converter.webm'
const REPEAT_VIDEO = '/videos/video_2026-10-16_03-54-478787877787_2x_upscaled-ezgif.com-video-to-webm-converter.webm'
const FIRST_VIDEO_SEEN_KEY = 'vendo-first-video-seen'
const ICONS_HIDDEN_KEY = 'vendo-intro-icons-hidden'

function readSessionStorage(key) {
  try {
    return window.sessionStorage.getItem(key)
  } catch {
    return null
  }
}

function App() {
  const [currentVideo, setCurrentVideo] = useState(() =>
    readSessionStorage(FIRST_VIDEO_SEEN_KEY) ? 'repeat' : 'first',
  )
  const [showMainPage, setShowMainPage] = useState(false)
  const [isTransitioning, setIsTransitioning] = useState(false)
  const [iconsVisible, setIconsVisible] = useState(() => !readSessionStorage(ICONS_HIDDEN_KEY))
  const [iconsFading, setIconsFading] = useState(false)

  const handleVideoEnded = () => {
    if (currentVideo === 'first') {
      try {
        window.sessionStorage.setItem(FIRST_VIDEO_SEEN_KEY, 'true')
      } catch {
        // Keep the video sequence working when storage is unavailable.
      }
      setCurrentVideo('repeat')
      return
    }

    try {
      window.sessionStorage.setItem(ICONS_HIDDEN_KEY, 'true')
    } catch {
      // Icons still fade for the current page even if storage is unavailable.
    }

    setIconsFading(true)
    setIsTransitioning(true)
    window.setTimeout(() => setIconsVisible(false), 800)
    window.setTimeout(() => setShowMainPage(true), 1000)
  }

  if (showMainPage) {
    return <MainPage />
  }

  return (
    <IntroScreen
      videoSrc={currentVideo === 'first' ? FIRST_VIDEO : REPEAT_VIDEO}
      isFirstVideo={currentVideo === 'first'}
      isTransitioning={isTransitioning}
      iconsVisible={iconsVisible}
      iconsFading={iconsFading}
      onVideoEnded={handleVideoEnded}
    />
  )
}

export default App
