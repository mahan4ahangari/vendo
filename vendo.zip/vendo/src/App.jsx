import { useState } from 'react'
import './App.css'

const FIRST_VIDEO = '/videos/video_2026-10-16_03-22-27_upscaled-ezgif.com-mp4-to-webm-converter.webm'
const REPEAT_VIDEO = '/videos/video_2026-10-16_03-54-478787877787_2x_upscaled-ezgif.com-video-to-webm-converter.webm'
const FIRST_VIDEO_SEEN_KEY = 'vendo-first-video-seen'

function App() {
  const [currentVideo, setCurrentVideo] = useState(() => {
    try {
      return window.sessionStorage.getItem(FIRST_VIDEO_SEEN_KEY) ? 'repeat' : 'first'
    } catch {
      return 'first'
    }
  })
  const [showHello, setShowHello] = useState(false)
  const [isTransitioning, setIsTransitioning] = useState(false)

  const handleVideoEnded = () => {
    if (currentVideo === 'first') {
      try {
        window.sessionStorage.setItem(FIRST_VIDEO_SEEN_KEY, 'true')
      } catch {
        // Continue playback if browser storage is unavailable.
      }
      setCurrentVideo('repeat')
    } else {
      setIsTransitioning(true)
      window.setTimeout(() => setShowHello(true), 1000)
    }
  }

  if (showHello) {
    return (
      <main className="hello-screen">
        <h1>hello</h1>
      </main>
    )
  }

  return (
    <main className="video-screen">
      <video
        key={currentVideo}
        className={`intro-video ${currentVideo === 'first' ? 'intro-video--cover' : 'intro-video--fade-in'} ${isTransitioning ? 'intro-video--fade-out' : ''}`}
        src={currentVideo === 'first' ? FIRST_VIDEO : REPEAT_VIDEO}
        autoPlay
        muted
        playsInline
        onEnded={handleVideoEnded}
        aria-label="Intro video"
      />
    </main>
  )
}

export default App
