import { useState } from 'react'
import './App.css'

const FIRST_VIDEO = '/videos/video_2026-10-16_03-22-27_upscaled-ezgif.com-mp4-to-webm-converter.webm'
const REPEAT_VIDEO = '/videos/video_2026-10-16_03-54-478787877787_2x_upscaled-ezgif.com-video-to-webm-converter.webm'
const FIRST_VIDEO_SEEN_KEY = 'vendo-first-video-seen'
const ICONS_HIDDEN_KEY = 'vendo-intro-icons-hidden'

function readSessionStorage(key) {
  try {
    return window.sessionStorage.getItem(key)
  } catch {
    return null
  }
}

function App() {
  const [currentVideo, setCurrentVideo] = useState(() => {
    try {
      return window.sessionStorage.getItem(FIRST_VIDEO_SEEN_KEY) ? 'repeat' : 'first'
    } catch {
      return 'first'
    }
  })
  const [showHello, setShowHello] = useState(false)
  const [isTransitioning, setIsTransitioning] = useState(false)
  const [iconsVisible, setIconsVisible] = useState(() => !readSessionStorage(ICONS_HIDDEN_KEY))
  const [iconsFading, setIconsFading] = useState(false)

  const handleVideoEnded = () => {
    if (currentVideo === 'first') {
      try {
        window.sessionStorage.setItem(FIRST_VIDEO_SEEN_KEY, 'true')
      } catch {
        // Continue playback if browser storage is unavailable.
      }
      setCurrentVideo('repeat')
    } else {
      try {
        window.sessionStorage.setItem(ICONS_HIDDEN_KEY, 'true')
      } catch {
        // Icons will still be hidden for the rest of this page session.
      }
      setIconsFading(true)
      setIsTransitioning(true)
      window.setTimeout(() => setIconsVisible(false), 800)
      window.setTimeout(() => setShowHello(true), 1000)
    }
  }

  const pageIcons = iconsVisible ? (
    <>
      <img
        className={`page-icon page-icon--top-left ${iconsFading ? 'page-icon--fade-out' : ''}`}
        src="/icons/icon-2.webp"
        alt=""
      />
      <img
        className={`page-icon page-icon--bottom-right ${iconsFading ? 'page-icon--fade-out' : ''}`}
        src="/icons/icon-1.webp"
        alt=""
      />
    </>
  ) : null

  if (showHello) {
    return (
      <main className="hello-screen">
        {pageIcons}
        <h1>hello</h1>
      </main>
    )
  }

  return (
    <main className="video-screen">
      {pageIcons}
      <video
        key={currentVideo}
        className={`intro-video ${currentVideo === 'first' ? 'intro-video--cover' : 'intro-video--fade-in'} ${isTransitioning ? 'intro-video--fade-out' : ''}`}
        src={currentVideo === 'first' ? FIRST_VIDEO : REPEAT_VIDEO}
        autoPlay
        muted
        playsInline
        onEnded={handleVideoEnded}
        aria-label="Intro video"
      />
    </main>
  )
}

export default App
