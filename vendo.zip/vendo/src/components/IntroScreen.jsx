import './IntroScreen.css'

function IntroScreen({
  videoSrc,
  isFirstVideo,
  isTransitioning,
  iconsVisible,
  iconsFading,
  onVideoEnded,
}) {
  return (
    <main className="video-screen">
      {/* Load the main-page logo while the intro videos are playing. */}
      <img className="logo-preload" src="/logo.webp" alt="" aria-hidden="true" fetchPriority="high" />
      <img className="background-preload" src="/background.webp" alt="" aria-hidden="true" fetchPriority="high" />
      <video
        className="mainpage-model-preload"
        src="/videos/video_2026-10-16_03-33-06_2x_upscaled-ezgif.com-video-to-webm-converter.webm"
        preload="auto"
        muted
        playsInline
        aria-hidden="true"
      />

      {iconsVisible && (
        <>
          <img
            className={`page-icon page-icon--top-left ${iconsFading ? 'page-icon--fade-out' : ''}`}
            src="/icons/icon-2.webp"
            alt=""
          />
          <img
            className={`page-icon page-icon--bottom-right ${iconsFading ? 'page-icon--fade-out' : ''}`}
            src="/icons/icon-1.webp"
            alt=""
          />
        </>
      )}

      <video
        className={`intro-video ${isFirstVideo ? 'intro-video--cover' : 'intro-video--fade-in'} ${isTransitioning ? 'intro-video--fade-out' : ''}`}
        src={videoSrc}
        autoPlay
        muted
        playsInline
        onEnded={onVideoEnded}
        aria-label="Intro video"
      />
    </main>
  )
}

export default IntroScreen
