import './MainPage.css'
import GlowingText from '../components/ui/GlowingText.jsx'
import TextEffect from '../components/ui/TextEffect.jsx'
import MusicPlayer from '../components/MusicPlayer.jsx'

function MainPage() {
  const stopModelOnBrightFrame = (event) => {
    const video = event.currentTarget
    if (video.currentTime >= 4.85) {
      video.pause()
      video.currentTime = 4.85
    }
  }

  return (
    <main className="hello-screen">
      <img className="mainpage-logo" src="/logo.webp" alt="Vendo" fetchPriority="high" />
      <MusicPlayer />
      <video
        className="mainpage-model"
        src="/videos/video_2026-10-16_03-33-06_2x_upscaled-ezgif.com-video-to-webm-converter.webm"
        autoPlay
        muted
        playsInline
        preload="auto"
        onTimeUpdate={stopModelOnBrightFrame}
        aria-hidden="true"
      />
      <div className="sky-effects" aria-hidden="true">
        <span className="comet comet--one" />
        <span className="comet comet--two" />
      </div>
      <section className="mainpage-content" aria-labelledby="mainpage-title">
        <GlowingText
          className="mainpage-title"
          text={'Your store, your way.\nBuilt for what’s next.'}
          glowColor="#9dffc0"
          characterStagger={0.025}
          revealDuration={0.7}
        />
        <TextEffect className="mainpage-description" preset="slide" delay={2} stagger={0.055}>
          Vendo is an online commerce platform in development, designed to help businesses launch and
          grow their online stores with less technical complexity.
        </TextEffect>
        <div className="mainpage-actions">
          <button className="mainpage-button mainpage-button--primary" type="button">
            Explore
          </button>
          <button className="mainpage-button mainpage-button--secondary" type="button">
            Our Work
          </button>
        </div>
      </section>
    </main>
  )
}

export default MainPage
